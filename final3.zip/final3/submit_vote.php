
<?php include ('sess.php');?>





<?php 
	session_start();
$candid= $_SESSION['pres_id'];
$votant= $_SESSION['voters_id'];
	session_destroy();
include("admin/dbcon.php");
	

	
			$localite = $conn->query("SELECT * FROM voters WHERE voters_id = '$votant'") or die(mysqli_errno());
		    $localite_row = $localite->fetch_array();
		     $localbureau = $localite_row['Circonscription'];
	

		$sql="INSERT INTO `votes` ( `candidate_id`, `voters_id`,`circonscription`) VALUES('$candid', '$votant','$localbureau')";
		$conn->query($sql);
	
		$conn->query("UPDATE voters SET `status` = 'Voted' WHERE `voters_id` = '$votant'") or die(mysql_error());
				?>
			<script type="text/javascript">
			alert("Votre vote a été enregistré avec succès");
			 window.location='index.php';
			</script>
			<?php

	
?> 