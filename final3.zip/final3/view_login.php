<style type="text/css">
nav ul li{
    display: inline-block;
    padding-left: 20px;
    padding-bottom: 10px;
}
nav ul li:hover{
    text-decoration: none;
}
a:hover{
    text-decoration: none;
}


</style>
            <div class="text-center text-success animateuse" style="background-color:rgba(0, 100, 0, 1); font-size:25px;text-align:center; margin-top:-10px; padding-top:20px;">
                <a style="color:white; font-weight:bold; font-size:30px;">Projet PHP Service web par Aminata Guissé</a>
              
        <nav class="nav-menue">
            <ul style = "color">
                <li>
                    <a href="index.php">Accueil</a>
                </li>
                <li><a href="candidate_path.php">Candidats</a></li>
                <li><a href="about.php" >A propos</a></li>
                <li> <a href="register/index.php">Inscription</a></li>
                <li><a href="voters.php" >Votants</a></li>
                <li><a href="login.php" style="color:white">Connexion</a></li>
            </ul>
        </nav>
					
</div>