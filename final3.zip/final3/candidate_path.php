


<body>

    <div id="wrapper">

        <!-- Navigation -->
              <?php include ('view_candidat.php');?>
        <!-- Page Content -->
        <div id="page-wrapper">

    <heading class="voters_heading">
    <?php include ('head.php');?>
        
<p/>

    </heading>
            <div class="row">
				
                    <div class="panel panel-default">
                       
                        <div class="panel-body">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example" border="0">

                                    <thead class="thead">                                    	
                                   
                                         <tr>
                                            <th>Image</th>
                                            <th>Prenom</th>
                                            <th>Nom</th>
                                            <th>Année de naissance</th>
                                            <th>Parti</th>
                                            <th>Sexe</th>
                                            
                                        </tr>
                                    </thead>
                                    <tbody>
									
                                        <tr>
										<?php 
											require 'admin/dbcon.php';
											$bool = false;
											$query = $conn->query("SELECT * FROM candidate WHERE `position` = 'President'");
												while($row = $query->fetch_array()){
													$candidate_id=$row['candidate_id'];
										?>
											
											<td width="50"><img src="admin/<?php echo $row['Photo']; ?>" width="50" height="50" class="img-rounded"></td>
                                            <td><?php echo $row ['Prenom'];?></td>
                                            <td><?php echo $row ['Nom'];?></td>
                                             <td><?php echo $row ['Anneedenaissance'];?></td>
                                            <td><?php echo $row ['Parti_politique'];?></td>
                                            <td><?php echo $row ['Sexe'];?></td>
                                        </tr>
										
                                       <?php } ?>
                                    </tbody>
                                </table>
                            
                            
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->



              
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->
    <?php    
        include ('footer.php');
        ?>

    <?php include ('script.php');?>



</body>

</html>

