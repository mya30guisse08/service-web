<?php 
   require 'dbcon.php';
			if (isset($_POST['save'])){
			$firstname=$_POST['firstname'];
			$lastname=$_POST['lastname'];
			$password=$_POST['password'];
			$password1=$_POST['password1'];
			$gender=$_POST['gender'];
			$id_number=$_POST['id_number'];
			$prog_naissance=$_POST['prog_naissance'];
			$adresse=$_POST['prog_adresse'];
			$centrevote = $_POST['prog_centrevote'];
			$bureau = $_POST['prog_bureau'];
			$circonscription = $_POST['prog_circonscription'];
			$date = date("Y-m-d H:i:s");

			$query = $conn->query("SELECT * FROM ids WHERE id_number LIKE '$id_number'") or die (mysql_error());
			$count = $query->fetch_array();
	if (mysqli_num_rows($query)==0){
	
?>
	<script>
			alert( 'l\'identifiant <?php echo $id_number ?> absent de la base' );
			window.location='index.php';
	</script>		
<?php
	}
	else{
		
		$query = $conn->query("SELECT * FROM voters WHERE id_number='$id_number'") or die (mysql_error());
		$count1 = $query->fetch_array();
		if ($count1 == 0) {
			if ($password == $password1) {
			$sql="INSERT INTO `voters` ( `id_number`, `firstname`, `lastname`, `gender`, `datedenaissance`, `status`, `account`, `date`, `password`, `Adresse`, `Nomcentredevote`, `Numerobureaudevote`, `Circonscription`) VALUES ( '$id_number', '$firstname', '$lastname', '$gender', '$prog_naissance', 'Unvoted', 'Active', '$date', '".md5($password)."', '$adresse', '$centrevote', '$bureau', '$circonscription');";
			
				$conn->query($sql);
			?>
	            <script>
			        alert( 'Inscription réussie');
			         window.location='../voters.php';
	            </script>
            <?php
           
			}else{
				?>
	            <script>
			        alert( 'Mot de passe inexact');
			         window.location='index.php';
	            </script>
            <?php
			}
		}else{
			?>
	            <script>
			        alert( 'Déjà inscrit');
			         window.location='../voters.php';
	            </script>
            <?php
		}
		

	}
} 
?>


					  