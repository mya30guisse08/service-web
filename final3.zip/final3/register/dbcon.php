<?php
	$conn = new mysqli('localhost', 'root', '', 'amyguisse');
	
	if(!$conn){
		die("Error: Failed to connect to database");
	}
?>	