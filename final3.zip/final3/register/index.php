
<?php include ('head.php');?>
<body>

    <div id="wrapper">
    	<?php    
        include ('index_banner.php');
        ?>
        <!-- Page Content -->
        <div id="page-wrapper">
            <div class="row">
			
					<div class="form-panel">
                      
                        <div class="form-body"> 

                         <form method = "post" enctype = "multipart/form-data">
                         	
                                <div class="form-heading">
                         		<center>Inscription sur les listes</center>
                         		</div>
											<div class="form-field">
												<label>Numero CNI</label><br/>
												<input class ="form-control" type = "text" name = "id_number" placeholder = "Numero CNI" required="true">
													
											</div>
											
											<div class="form-field">											
												<label>mot de passe</label><br/>
													<input class="form-control"  type = "password" name = "password" id = "pass" placeholder="mot de passe" required="true"/>
											</div>
											<div class="form-field">											
												<label>Confirmer le mot de passe</label><br/>
													<input class="form-control"  type = "password" name = "password1" id = "pass" placeholder="Confirmer le mot de passe" required="true"/>
											</div>

											<div class="form-field">
												<label>Prénom</label><br/>
													<input class="form-control" type ="text" name = "firstname" placeholder="Prénom" required="true">
											</div>
											
											<div class="form-field">
												<label>Nom</label><br/>
													<input class="form-control"  type = "text" name = "lastname" placeholder="Nom" required="true">
											</div>

											<div class="form-field">
												<label>Sexe</label> <br/>
													<select class = "form-control" name = "gender" required="true">
														<option value="Male">Male</option>
														<option value="Female">Femelle</option>														
													</select>
											</div>
											
											<div class="form-field">
											<label>Date de naissance</label><br/>
													<input class="form-control"  type = "date" name = "prog_naissance" placeholder="Date de naissance" required="true">
											</div>
											
											<div class="form-field">
												<label>Adresse</label><br/>
													<input class="form-control"  type = "text" name = "prog_adresse" placeholder="adresse" required="true">
											</div>
											
											<div class="form-field">
												<label>Nom centre de vote</label><br/>
													<input class="form-control"  type = "text" name = "prog_centrevote" placeholder="Nom centre de vote" required="true">
											</div>
											
											<div class="form-field">
												<label>Numéro bureau de vote</label><br/>
													<input class="form-control"  type = "number" name = "prog_bureau" placeholder="Numéro bureau de vote" required="true">
											</div>
											

											<div class="form-field">
												<label>Circonscription</label> <br/>
													<select class = "form-control" name = "prog_circonscription" required="true">
														<option value="Dakar ville">Dakar ville</option>
														<option value="Diourbel">Diourbel</option>
														<option value="Guediawaye">Guediawaye</option>
														<option value="Matam">Matam</option>
														<option value="Mbour">Mbour</option>
														<option value="Parcelles assainies">Parcelles assainies</option>
														<option value="Pikine">Pikine</option>
														<option value="Saint-louis">Saint-louis</option>
														<option value="Thies ville">Thies ville</option>
														<option value="Ziguinchor">Ziguinchor</option>
														
													</select>
											</div>
												<br/>					
											 	 <center><button name = "save" type="submit">Creer mon compte</button></center>
                                            <div class="link">
											 	 <h2><center><a href="../login.php" style = "font-size:16px;">Connexion pour voter</a></center></h2>
											</div>

						  				 </div>
                                       
										
										</form>
								
							<?php //PHP script to insert signup data into database
								require 'signUpData.php';
								
							?>

						</div>
						    
					</form>
					
                    </div>
                </div>
            
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->
        <?php 
        include ('footer.php');
        ?>

    </div>
    <!-- /#wrapper -->
</body>

</html>

