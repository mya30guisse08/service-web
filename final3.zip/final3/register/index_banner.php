
            <div class="side-bar" 
            style="background-color:rgba(0, 100, 0, 1); font-size:25px; text-align:center; margin-top:-10px; padding-top:20px;">

                <a href="#" style="color:white; font-weight:bold; font-size:30px;">Projet PHP Service web par Aminata Guissé
</a>
                </a>
        <nav class="nav-menue">
            <ul>
                <li>
                    <a href="../index.php">Accueil</a>
                </li>
                <li><a href="../view.php">Candidats</a></li>
                <li><a href="../about.php">A propos</a></li>
                <li><a href="#" style="color:white">Inscription</a></li>
                <li><a href="../voters.php">Liste des Votants</a></li>
                <li><a href="../login.php">Connexion</a></li>
            </ul>
        </nav>
    </div>