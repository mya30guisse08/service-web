
<div class="side-bar" 
            style="background-color:rgba(0, 100, 0, 1); font-size:25px; text-align:center; margin-top:-10px; padding-top:20px; padding-bottom:0px;">

                <a href="#" style="color:white; font-weight:bold; font-size:30px;">Projet PHP Service web par Aminata Guissé
</a>
                </a>

        <nav class="nav-menue">
            <ul>
                <li>
                    <a href="index.php">Acceuil</a>
                </li>
                <li><a href="view.php">Candidats</a></li>
                <li><a href="./about.php">A propos</a></li>
                <li><a href="register/index.php">Inscription</a></li>
                <li><a href="voters.php">Votants</a></li>
                <li><a href="login.php">Connexion</a></li>
            </ul>
        </nav>
    </div>
					
</div>