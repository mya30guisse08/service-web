

<div class="panel-nav">
    <div class="menue">
       <center><h3 class="panel-title"><a href="index.php">Accueil</a> | <a href="view.php">Candidats</a> | <a href="about.php">A propos</a> | <a href="voters.php">Votants</a></h3></center>
    </div>
</div>