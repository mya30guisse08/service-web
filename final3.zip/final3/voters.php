<?php include ('head.php');?>

<body>
 <?php include ('view_voter.php');?>
<div class="col-lg-6">

     
    <center>
        <div class="voters_notice">
            <p><strong><i>NOTE</i>:</strong> Seuls ceux qui sont inscrits sur les listes verront leur nom ici.</p>
        </div>
        <strong><h3>Liste des inscrits</h3></strong>
       <strong><h3> <a href="mailto:reclamations_sn@gmail.com" style="color:red">Cliquez ici pour faire des reclamations</a></h3></strong>

    </center>

 &nbsp;

                    <div class="tables-body">
                            <div class="table_back">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example" border="0">
                                    <thead class="thead">
                                        <tr>
                                         
                                            <th>CNI</th>
                                            <th>Nom et prenom</th>
                                            <th>Sexe</th>
                                            <th>Date de naissance</th>
                                            <th>Adresse</th>
                                            <th>Circonscription</th>
                                            <th>Centre de vote</th>
                                            <th>Bureau</th>
                                            <th>Compte</th>
                                            <th>Statut</th>
                                            <th>Date inscription</th>
                                            
                                            
                                        </tr>
                                    </thead>
                                    <tbody>
										<?php 
											require 'admin/dbcon.php';
											
											$query = $conn->query("SELECT * FROM voters ORDER BY voters_id DESC");
											while($row1 = $query->fetch_array()){
											$voters_id=$row1['voters_id'];
										?>
                                      
											<tr >
												<td><?php echo $row1 ['id_number'];?></td>
												<td><?php echo $row1 ['firstname']." ". $row1 ['lastname'];?></td>
                                                <td><?php echo $row1 ['gender'];?></td>
                                                <td><?php echo $row1['datedenaissance'];?></td>
												<td><?php echo $row1 ['Adresse'];?></td>
                                                <td><?php echo $row1 ['Circonscription'];?></td>
                                                <td><?php echo $row1 ['Nomcentredevote'];?></td>
                                                <td><?php echo $row1 ['Numerobureaudevote'];?></td>
                                                <td><?php echo $row1 ['account'];?></td>
												<td><?php echo $row1 ['status'];?></td>
												<td><?php echo $row1 ['date'];?></td>		
											</tr>
										
                                       <?php } ?>
                                    </tbody>
                                </table>

                             </div>
                    </div>
         

</div>                          
        <?php 
            include ('script.php');
        ?>                     
</body>
</html>