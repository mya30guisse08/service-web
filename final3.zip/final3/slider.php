<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="css/SliderCss.css">
</head>
<body>

</body>
</html>
<div id="slider">
	<figure>
<img src="img/c.jpg">
<img src="img/aold.jpg">
<img src="img/bold.png">
<img src="img/_d.jpg">
<img src="img/c.jpg">
    </figure>
</div>
