
<footer class="footer">
	<hr/>
&copy2022. Developpé par Amy guissé : BIT1510297.
<br/>
Système de gestion des elections
<br/>
Université de Thiès
<br/>
Contact: <a href="tel:+260979848064">+77 709 69 32</a> | Email: <a href="mailto:reclamations_sn@gmail.com" style="color:red">Faites des reclamations</a>

</footer>
