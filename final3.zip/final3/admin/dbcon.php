<?php
	$conn = new mysqli('localhost', 'root', '', 'amyguisse');
	
	if(!$conn){
		die("Erreur de connexion a la base de donnée");
	}
?>	