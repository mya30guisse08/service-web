<?php include ('head.php');?>

<body>
	<?php include ('view_about.php');?>

    <heading class="voters_heading">
        <center><h1>Projet commun de gestion des elections</h1>
    </heading>
    <div class="image">
    	<img src="thies.jpg" width="40%" height="40%"/>
    </div>
    <div class="union-infor">
    	
    </div>


    <?php    
        include ('footer.php');
        ?>

   </body>
</html>

